// Local Authentication Manager for Stress Out App
class LocalAuthManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }
    
    init() {
        // Check for existing session
        const storedUser = localStorage.getItem('stressOutUser');
        if (storedUser) {
            try {
                this.currentUser = JSON.parse(storedUser);
                this.updateAuthUI();
            } catch (error) {
                console.error('Error parsing stored user:', error);
                localStorage.removeItem('stressOutUser');
            }
        }
    }
    
    isUserAuthenticated() {
        return this.currentUser !== null;
    }
    
    getCurrentUser() {
        return this.currentUser;
    }
    
    async login(username, password) {
        try {
            const users = await this.getUsers();
            const user = users.find(u => u.username === username);
            
            if (!user) {
                throw new Error('User not found');
            }
            
            if (user.password !== password) {
                throw new Error('Invalid password');
            }
            
            this.currentUser = {
                id: user.id,
                username: user.username,
                loginTime: new Date().toISOString()
            };
            
            localStorage.setItem('stressOutUser', JSON.stringify(this.currentUser));
            this.updateAuthUI();
            return this.currentUser;
        } catch (error) {
            console.error('Login error:', error);
            throw error;
        }
    }
    
    async signup(username, password) {
        try {
            const users = await this.getUsers();
            
            if (users.find(u => u.username === username)) {
                throw new Error('Username already exists');
            }
            
            const newUser = {
                id: Date.now().toString(),
                username: username,
                password: password,
                createdAt: new Date().toISOString()
            };
            
            users.push(newUser);
            await this.saveUsers(users);
            
            return newUser;
        } catch (error) {
            console.error('Signup error:', error);
            throw error;
        }
    }
    
    logout() {
        this.currentUser = null;
        localStorage.removeItem('stressOutUser');
        this.updateAuthUI();
    }
    
    async getUsers() {
        try {
            const response = await fetch('/api/users');
            if (response.ok) {
                const csv = await response.text();
                return this.parseCSV(csv);
            }
        } catch (error) {
            console.log('No existing users file, starting fresh');
        }
        return [];
    }
    
    async saveUsers(users) {
        const csv = this.toCSV(users);
        await fetch('/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'text/csv' },
            body: csv
        });
    }
    
    parseCSV(csv) {
        if (!csv.trim()) return [];
        
        const lines = csv.trim().split('\n');
        const headers = lines[0].split(',');
        return lines.slice(1).map(line => {
            const values = line.split(',');
            const user = {};
            headers.forEach((header, index) => {
                user[header.trim()] = values[index]?.trim() || '';
            });
            return user;
        });
    }
    
    toCSV(users) {
        if (users.length === 0) return 'id,username,password,createdAt\n';
        
        const headers = Object.keys(users[0]);
        const csv = [headers.join(',')];
        
        users.forEach(user => {
            const values = headers.map(header => user[header] || '');
            csv.push(values.join(','));
        });
        
        return csv.join('\n');
    }
    
    updateAuthUI() {
        const authContainer = document.getElementById('authContainer');
        if (!authContainer) return;
        
        if (this.isUserAuthenticated()) {
            // Show user info and logout button
            authContainer.innerHTML = `
                <div class="user-info">
                    <div class="user-details">
                        <div class="user-name">${this.currentUser.username}</div>
                        <div class="user-email">Signed in</div>
                    </div>
                    <button class="auth-button sign-out" onclick="window.authManager.logout()">Sign Out</button>
                </div>
            `;
        } else {
            // Show sign in button
            authContainer.innerHTML = `
                <button class="auth-button" onclick="window.location.href='/signin.html'">Sign In</button>
            `;
        }
    }
    
    // Protect content that requires authentication
    protectContent() {
        if (!this.isUserAuthenticated()) {
            // Hide protected content
            document.querySelectorAll('.protected-content').forEach(el => {
                el.style.display = 'none';
            });
            
            // Show sign-in prompt
            const signInPrompt = document.querySelector('.sign-in-prompt');
            if (signInPrompt) {
                signInPrompt.style.display = 'block';
            }
        } else {
            // Show protected content
            document.querySelectorAll('.protected-content').forEach(el => {
                el.style.display = 'block';
            });
            
            // Hide sign-in prompt
            const signInPrompt = document.querySelector('.sign-in-prompt');
            if (signInPrompt) {
                signInPrompt.style.display = 'none';
            }
        }
    }
}

// Initialize global auth manager
window.authManager = new LocalAuthManager();

// Auto-update UI when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.authManager.updateAuthUI();
    window.authManager.protectContent();
});
