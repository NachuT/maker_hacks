import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const res = await fetch('http://localhost:5010/api/result', { cache: 'no-store' })
    if (!res.ok) throw new Error('Flask upstream not available')
    const data = await res.json()
    return NextResponse.json(data, { headers: { 'Cache-Control': 'no-store' } })
  } catch (e) {
    return NextResponse.json({ error: 'unavailable' }, { status: 503 })
  }
}


