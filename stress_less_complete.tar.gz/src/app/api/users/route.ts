import { NextRequest, NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'

const USERS_FILE = path.join(process.cwd(), 'data', 'users.csv')

// Ensure data directory exists
async function ensureDataDir() {
  const dataDir = path.dirname(USERS_FILE)
  try {
    await fs.access(dataDir)
  } catch {
    await fs.mkdir(dataDir, { recursive: true })
  }
}

// GET /api/users - Read users from CSV
export async function GET() {
  try {
    await ensureDataDir()
    
    try {
      const csv = await fs.readFile(USERS_FILE, 'utf-8')
      return new NextResponse(csv, {
        headers: {
          'Content-Type': 'text/csv',
        },
      })
    } catch (error) {
      // File doesn't exist, return empty CSV
      return new NextResponse('id,username,password,createdAt\n', {
        headers: {
          'Content-Type': 'text/csv',
        },
      })
    }
  } catch (error) {
    console.error('Error reading users:', error)
    return NextResponse.json({ error: 'Failed to read users' }, { status: 500 })
  }
}

// POST /api/users - Write users to CSV
export async function POST(request: NextRequest) {
  try {
    await ensureDataDir()
    
    const csv = await request.text()
    await fs.writeFile(USERS_FILE, csv, 'utf-8')
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error saving users:', error)
    return NextResponse.json({ error: 'Failed to save users' }, { status: 500 })
  }
}
