// Live Data Manager - Real-time updates from Flask
class LiveDataManager {
    constructor() {
        this.callbacks = [];
        this.pollingInterval = null;
        this.isPolling = false;
    }
    
    startPolling() {
        if (this.isPolling) return;
        
        this.isPolling = true;
        console.log('📡 Starting live data polling...');
        
        this.pollingInterval = setInterval(async () => {
            try {
                const response = await fetch('/api/live');
                if (response.ok) {
                    const data = await response.json();
                    this.notifyCallbacks(data);
                }
            } catch (error) {
                console.error('📡 Polling error:', error);
            }
        }, 1000); // Poll every second for real-time updates
    }
    
    stopPolling() {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
        this.isPolling = false;
        console.log('📡 Stopped live data polling');
    }
    
    subscribe(callback) {
        this.callbacks.push(callback);
        
        // If this is the first subscriber, start polling
        if (this.callbacks.length === 1) {
            this.startPolling();
        }
        
        // Return unsubscribe function
        return () => {
            const index = this.callbacks.indexOf(callback);
            if (index > -1) {
                this.callbacks.splice(index, 1);
            }
            
            // If no more subscribers, stop polling
            if (this.callbacks.length === 0) {
                this.stopPolling();
            }
        };
    }
    
    notifyCallbacks(data) {
        this.callbacks.forEach(callback => {
            try {
                callback(data);
            } catch (error) {
                console.error('📡 Callback error:', error);
            }
        });
    }
}

// Global instance
window.liveDataManager = new LiveDataManager();
