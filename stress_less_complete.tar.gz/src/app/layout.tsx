import type { Metadata, Viewport } from 'next'

export const metadata: Metadata = {
  title: 'Stress Less',
  description: 'Breathe, relax, and find your calm',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  )
}


