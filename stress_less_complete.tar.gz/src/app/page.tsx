import { redirect } from 'next/navigation'

export default function Home() {
  // Redirect to sign-in page first, then to main app
  redirect('/signin.html')
}


